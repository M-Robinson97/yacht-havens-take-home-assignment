import { Contract } from 'src/app/models/contract.model';

export interface EditContractDialogData {
    contract: Contract;
}
