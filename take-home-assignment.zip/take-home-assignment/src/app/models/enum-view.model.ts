export class EnumView<T> {
    constructor(public id: number, public name: T) {}
}
