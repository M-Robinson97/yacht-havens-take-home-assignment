export enum ContractType {
    Resident = 'Resident',
    Visitor = 'Visitor',
    Seasonal = 'Seasonal',
}
