export enum ContractStatus {
    Active = 'Active',
    Initial = 'Initial',
    Completed = 'Completed',
    Cancelled = 'Cancelled',
}
